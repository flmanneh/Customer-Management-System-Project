import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_migrate import Migrate
from werkzeug.security import generate_password_hash
from datetime import datetime

# Initialize extensions
db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = "login"  
login_manager.login_message_category = "info"
migrate = Migrate()

def create_app():
    app = Flask(__name__, template_folder="../templates")

    # Config
    app.config['SECRET_KEY'] = os.environ.get("SECRET_KEY") or "supersecretkey"
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///nifty.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Initialize extensions with app
    db.init_app(app)
    login_manager.init_app(app)
    migrate.init_app(app, db)

    # Import models once here
    from app import models  

    # Create database tables if not exist
    with app.app_context():
        db.create_all()

        # Create default admin if no users
        from app.models import User
        if User.query.count() == 0:
            admin = User(
                username="admin",
                email="admin@example.com",
                role="admin",
                password_hash=generate_password_hash("admin123"),
                date_created=datetime.utcnow()
            )
            db.session.add(admin)
            db.session.commit()
            print("Default admin account created: admin / admin123")

    # Import and register routes
    from app import routes
    routes.register_routes(app)

    return app
