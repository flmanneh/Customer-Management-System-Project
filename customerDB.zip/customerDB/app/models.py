from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db, login_manager


# Flask-Login user loader
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


class User(db.Model, UserMixin):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    role = db.Column(db.String(10), default="staff")  # "admin" or "staff"
    password_hash = db.Column(db.String(128), nullable=False)
    date_created = db.Column(db.DateTime, default=datetime.utcnow)

    # Relationship to customers
    customers = db.relationship("Customer", backref="creator", lazy=True)

    def set_password(self, password):
        """Hash and store the password."""
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        """Verify a password."""
        return check_password_hash(self.password_hash, password)

    def is_admin(self):
        """Check if the user has admin privileges."""
        return self.role.lower() == "admin"

    def __repr__(self):
        return f"<User {self.username}>"


class Customer(db.Model):
    __tablename__ = "customers"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120))
    phone = db.Column(db.String(50))
    address = db.Column(db.Text)
    gender = db.Column(db.String(10))  
    product_purchased =db.Column(db.String(250))
    date_added = db.Column(db.DateTime, default=datetime.utcnow)

    # Foreign key to User (explicit FK name to avoid SQLite error)
    created_by = db.Column(
        db.Integer,
        db.ForeignKey('users.id', name="fk_customers_created_by_users_id"),
        nullable=False
    )

    def __repr__(self):
        return f"<Customer {self.name}>"
