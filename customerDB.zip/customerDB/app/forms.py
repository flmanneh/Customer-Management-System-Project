from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, SelectField, TextAreaField
from wtforms.validators import DataRequired, Email, EqualTo, Length, Optional


# Login Form
class LoginForm(FlaskForm):
    username = StringField("Username", validators=[DataRequired(), Length(min=3, max=64)])
    password = PasswordField("Password", validators=[DataRequired()])
    submit = SubmitField("Login")


# User Form (Add/Edit User)
class UserForm(FlaskForm):
    username = StringField("Username", validators=[DataRequired(), Length(min=3, max=64)])
    email = StringField("Email", validators=[DataRequired(), Email()])
    role = SelectField("Role", choices=[("admin", "Admin"), ("staff", "Staff")], validators=[DataRequired()])
    password = PasswordField("Password", validators=[Optional(), Length(min=6)])
    confirm_password = PasswordField("Confirm Password", validators=[Optional(), EqualTo("password", message="Passwords must match")])
    submit = SubmitField("Save")


# Customer Form (Add/Edit Customer)
class CustomerForm(FlaskForm):
    name = StringField("Name", validators=[DataRequired(), Length(min=2, max=120)])
    email = StringField("Email", validators=[DataRequired(), Email()])
    phone = StringField("Phone", validators=[DataRequired(), Length(max=50)])
    address = TextAreaField("Address", validators=[DataRequired(), Length(max=500)])
    gender = SelectField("Gender", choices=[("male", "Male"), ("female", "Female")], validators=[DataRequired()])
    product_purchased = StringField("Product Purchased", validators=[DataRequired(), Length(max=500)])
    submit = SubmitField("Save")


# Profile Form (Update Profile & Change Password)
class ProfileForm(FlaskForm):
    username = StringField("Username", validators=[DataRequired(), Length(min=3, max=64)])
    email = StringField("Email", validators=[DataRequired(), Email()])
    current_password = PasswordField("Current Password", validators=[Optional()])
    new_password = PasswordField("New Password", validators=[Optional(), Length(min=6)])
    confirm_new_password = PasswordField("Confirm New Password", validators=[Optional(), EqualTo("new_password", message="Passwords must match")])
    submit = SubmitField("Update Profile")
