from datetime import datetime, timezone
from flask import render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user, login_user, logout_user
from sqlalchemy import func
from app import db
from app.models import User, Customer
from app.forms import LoginForm, UserForm, CustomerForm, ProfileForm


def register_routes(app):

    # ------------------------------
    # Home route: Redirect based on login status
    # ------------------------------
    @app.route('/')
    def home():
        if current_user.is_authenticated:
            return redirect(url_for('dashboard'))
        return redirect(url_for('login'))

    # ------------------------------
    # Login
    # ------------------------------
    @app.route("/login", methods=["GET", "POST"])
    def login():
        if current_user.is_authenticated:
            return redirect(url_for("dashboard"))

        form = LoginForm()
        if form.validate_on_submit():
            user = User.query.filter_by(username=form.username.data).first()
            if user and user.check_password(form.password.data):
                login_user(user)
                return redirect(url_for("dashboard"))
            else:
                flash("Invalid username or password", "danger")
        return render_template("login.html", form=form)

    # ------------------------------
    # Logout
    # ------------------------------
    @app.route("/logout")
    @login_required
    def logout():
        logout_user()
        return redirect(url_for("login"))

    # ------------------------------
    # Dashboard
    # ------------------------------
    @app.route("/dashboard")
    @login_required
    def dashboard():
        total_customers = Customer.query.count()
        total_users = User.query.count()

        growth_data = {}
        now = datetime.now(timezone.utc)

        for i in range(5, -1, -1):
            month = (now.month - i - 1) % 12 + 1
            year = now.year - ((now.month - i - 1) // 12)
            label = f"{year}-{month:02d}"
            count = Customer.query.filter(
                func.extract("year", Customer.date_added) == year,
                func.extract("month", Customer.date_added) == month
            ).count()
            growth_data[label] = count

        growth_data_labels = list(growth_data.keys())
        growth_data_values = list(growth_data.values())

        role_distribution = {
            "admin": User.query.filter_by(role="admin").count(),
            "staff": User.query.filter_by(role="staff").count()
        }
        role_data = [
            int(role_distribution.get("admin") or 0),
            int(role_distribution.get("staff") or 0)
        ]

        recent_customers = Customer.query.order_by(Customer.date_added.desc()).limit(5).all()

        return render_template(
            "dashboard.html",
            total_customers=total_customers,
            total_users=total_users,
            growth_data_labels=growth_data_labels,
            growth_data_values=growth_data_values,
            role_data=role_data,
            recent_customers=recent_customers
        )


    # ------------------------------
    # Customers
    # ------------------------------
    @app.route("/customers")
    @login_required
    def customers():
        all_customers = Customer.query.order_by(Customer.date_added.desc()).all()
        return render_template("customers.html", customers=all_customers)

    @app.route("/customer/add", methods=["GET", "POST"])
    @login_required
    def add_customer():
        form = CustomerForm()
        if form.validate_on_submit():
            customer = Customer(
                name=form.name.data,
                email=form.email.data,
                phone=form.phone.data,
                address=form.address.data,
                gender=form.gender.data,
                product=form.product_purchased.data,
                created_by=current_user.id
            )
            db.session.add(customer)
            db.session.commit()
            flash("Customer added successfully", "success")
            return redirect(url_for("customers"))
        return render_template("customer_form.html", form=form)

    @app.route("/customer/edit/<int:customer_id>", methods=["GET", "POST"])
    @login_required
    def edit_customer(customer_id):
        customer = Customer.query.get_or_404(customer_id)
        form = CustomerForm(obj=customer)
        if form.validate_on_submit():
            customer.name = form.name.data
            customer.email = form.email.data
            customer.phone = form.phone.data
            customer.address = form.address.data
            customer.gender = form.gender.data
            customer.product_purchased = form.product_purchased.data
            db.session.commit()
            flash("Customer updated successfully", "success")
            return redirect(url_for("customers"))
        return render_template("customer_form.html", form=form)

    @app.route("/customer/delete/<int:customer_id>")
    @login_required
    def delete_customer(customer_id):
        customer = Customer.query.get_or_404(customer_id)
        db.session.delete(customer)
        db.session.commit()
        flash("Customer deleted successfully", "success")
        return redirect(url_for("customers"))

    # ------------------------------
    # Users (Admin only)
    # ------------------------------
    @app.route("/users")
    @login_required
    def users():
        if not current_user.is_admin():
            flash("Access denied", "danger")
            return redirect(url_for("dashboard"))
        all_users = User.query.order_by(User.date_created.desc()).all()
        return render_template("users.html", users=all_users)

    @app.route("/user/add", methods=["GET", "POST"])
    @login_required
    def add_user():
        if not current_user.is_admin():
            flash("Access denied", "danger")
            return redirect(url_for("dashboard"))

        form = UserForm()
        if form.validate_on_submit():
            user = User(
                username=form.username.data,
                email=form.email.data,
                role=form.role.data
            )
            if form.password.data:
                user.set_password(form.password.data)
            db.session.add(user)
            db.session.commit()
            flash("User added successfully", "success")
            return redirect(url_for("users"))
        return render_template("user_form.html", form=form)

    @app.route("/user/edit/<int:user_id>", methods=["GET", "POST"])
    @login_required
    def edit_user(user_id):
        if not current_user.is_admin():
            flash("Access denied", "danger")
            return redirect(url_for("dashboard"))

        user = User.query.get_or_404(user_id)
        form = UserForm(obj=user)
        if form.validate_on_submit():
            user.username = form.username.data
            user.email = form.email.data
            user.role = form.role.data
            if form.password.data:
                user.set_password(form.password.data)
            db.session.commit()
            flash("User updated successfully", "success")
            return redirect(url_for("users"))
        return render_template("user_form.html", form=form)

    @app.route("/user/delete/<int:user_id>")
    @login_required
    def delete_user(user_id):
        if not current_user.is_admin():
            flash("Access denied", "danger")
            return redirect(url_for("dashboard"))

        user = User.query.get_or_404(user_id)
        db.session.delete(user)
        db.session.commit()
        flash("User deleted successfully", "success")
        return redirect(url_for("users"))

    # ------------------------------
    # Profile
    # ------------------------------
    @app.route("/profile", methods=["GET", "POST"])
    @login_required
    def profile():
        form = ProfileForm(obj=current_user)
        if form.validate_on_submit():
            current_user.username = form.username.data
            current_user.email = form.email.data

            if form.current_password.data:
                if current_user.check_password(form.current_password.data):
                    if form.new_password.data:
                        current_user.set_password(form.new_password.data)
                else:
                    flash("Current password is incorrect", "danger")
                    return redirect(url_for("profile"))

            db.session.commit()
            flash("Profile updated successfully", "success")
            return redirect(url_for("profile"))

        return render_template("profile.html", form=form)
